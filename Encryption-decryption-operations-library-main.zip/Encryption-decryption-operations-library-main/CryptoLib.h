#ifndef CRYPTOLIB_H
#define CRYPTOLIB_H

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;
class CryptoKey {
private:
    int    shift;       
    int    multiplier;  
    string label;       

public:
    CryptoKey() {
        shift = 3;
        multiplier = 1;
        label = "DefaultKey";
    }

    CryptoKey(int s) {
        shift = s % 26;
        multiplier = 1;
        label = "ShiftKey";
    }

    CryptoKey(int s, int m, string lbl) {
        shift = s;
        multiplier = m;
        label = lbl;
    }
    int    getShift()      const { return shift; }
    int    getMultiplier() const { return multiplier; }
    string getLabel()      const { return label; }
    CryptoKey operator+(const CryptoKey& other) const {
        int newShift = (shift + other.shift) % 26;
        int newMult = (multiplier * other.multiplier) % 26;
        string newLabel = label + "+" + other.label;
        return CryptoKey(newShift, newMult, newLabel);
    }

    CryptoKey operator-(int val) const {
        int newShift = ((shift - val) % 26 + 26) % 26;
        string newLabel = label + "-weakened";
        return CryptoKey(newShift, multiplier, newLabel);
    }

    CryptoKey operator*(int factor) const {
        int newShift = (shift * factor) % 26;
        string newLabel = label + "-strengthened";
        return CryptoKey(newShift, multiplier, newLabel);
    }

    bool operator==(const CryptoKey& other) const {
        if (shift == other.shift && multiplier == other.multiplier)
            return true;
        return false;
    }

    bool operator<(const CryptoKey& other) const {
        if (shift < other.shift)
            return true;
        return false;
    }

    friend ostream& operator<<(ostream& os, const CryptoKey& k) {
        os << "Key Label    : " << k.label << "\n"
            << "Shift Value  : " << k.shift << "\n"
            << "Multiplier   : " << k.multiplier << "\n";
        return os;
    }
};
class CipherText {
private:
    string data;
    string algorithm;
    int    keyShift;

public:
    CipherText() {
        data = "";
        algorithm = "NONE";
        keyShift = 0;
    }

    CipherText(string d, string algo) {
        data = d;
        algorithm = algo;
        keyShift = 0;
    }

    CipherText(string d, string algo, int ks) {
        data = d;
        algorithm = algo;
        keyShift = ks;
    }
    string getData()      const { return data; }
    string getAlgorithm() const { return algorithm; }
    int    getKeyShift()  const { return keyShift; }
    CipherText operator+(const CipherText& other) const {
        return CipherText(data + other.data,
                          algorithm + "+" + other.algorithm,
                          keyShift);
    }

    bool operator==(const CipherText& other) const {
        return (data == other.data && algorithm == other.algorithm);
    }
    bool operator<(const CipherText& other) const {
        return data.length() < other.data.length();
    }
    friend ostream& operator<<(ostream& os, const CipherText& c) {
        os << "CipherText[" << c.algorithm << "] keyShift=" << c.keyShift
           << " | Data: \"" << c.data << "\"";
        return os;
    }
};
class EncryptionEngine {
private:
    CryptoKey activeKey;
    string    engineName;
    int       operationCount;

public:
    EncryptionEngine()
        : activeKey(), engineName("DefaultEngine"), operationCount(0) {}

    EncryptionEngine(CryptoKey key)
        : activeKey(key), engineName("CustomEngine"), operationCount(0) {}

    EncryptionEngine(CryptoKey key, string name)
        : activeKey(key), engineName(name), operationCount(0) {}
    CryptoKey getKey()           const { return activeKey; }
    string    getName()          const { return engineName; }
    int       getOpCount()       const { return operationCount; }
    CipherText caesarEncrypt(const string& plainText) {
        string result = "";
        int s = activeKey.getShift();
        for (char c : plainText) {
            if (isalpha(c)) {
                char base = isupper(c) ? 'A' : 'a';
                result += char((c - base + s + 26) % 26 + base);
            } else {
                result += c;
            }
        }
        operationCount++;
        return CipherText(result, "CAESAR", s);
    }

    string caesarDecrypt(const CipherText& ct) {
        string result = "";
        int s = ct.getKeyShift();
        for (char c : ct.getData()) {
            if (isalpha(c)) {
                char base = isupper(c) ? 'A' : 'a';
                result += char((c - base - s + 26) % 26 + base);
            } else {
                result += c;
            }
        }
        operationCount++;
        return result;
    }

    CipherText rot13Encrypt(const string& plainText) {
        string result = "";
        for (char c : plainText) {
            if (isalpha(c)) {
                char base = isupper(c) ? 'A' : 'a';
                result += char((c - base + 13) % 26 + base);
            } else {
                result += c;
            }
        }
        operationCount++;
        return CipherText(result, "ROT13", 13);
    }

    string rot13Decrypt(const CipherText& ct) {
        // ROT13 is self-inverse
        operationCount++;
        return rot13Encrypt(ct.getData()).getData();
    }
    CipherText vigenereEncrypt(const string& plainText, const string& keyword) {
        string result = "";
        int keyLen = keyword.length();
        int j = 0;
        for (char c : plainText) {
            if (isalpha(c)) {
                char base  = isupper(c) ? 'A' : 'a';
                int  shift = tolower(keyword[j % keyLen]) - 'a';
                result += char((c - base + shift) % 26 + base);
                j++;
            } else {
                result += c;
            }
        }
        operationCount++;
        return CipherText(result, "VIGENERE", 0);
    }

    string vigenereDecrypt(const CipherText& ct, const string& keyword) {
        string result = "";
        int keyLen = keyword.length();
        int j = 0;
        for (char c : ct.getData()) {
            if (isalpha(c)) {
                char base  = isupper(c) ? 'A' : 'a';
                int  shift = tolower(keyword[j % keyLen]) - 'a';
                result += char((c - base - shift + 26) % 26 + base);
                j++;
            } else {
                result += c;
            }
        }
        operationCount++;
        return result;
    }
    CipherText xorEncrypt(const string& plainText) {
        string result = "";
        int key = activeKey.getShift();
        for (char c : plainText)
            result += char(c ^ key);
        operationCount++;
        return CipherText(result, "XOR", key);
    }

    string xorDecrypt(const CipherText& ct) {
        // XOR is self-inverse
        string result = "";
        int key = ct.getKeyShift();
        for (char c : ct.getData())
            result += char(c ^ key);
        operationCount++;
        return result;
    }
    EncryptionEngine operator+(const EncryptionEngine& other) const {
        EncryptionEngine merged(activeKey + other.activeKey, engineName + "+" + other.engineName);
        merged.operationCount = operationCount + other.operationCount;
        return merged;
    }
    EncryptionEngine operator*(int factor) const {
        EncryptionEngine stronger(activeKey * factor, engineName + "-strengthened");
        stronger.operationCount = operationCount;
        return stronger;
    }
    bool operator==(const EncryptionEngine& other) const {
        return activeKey == other.activeKey;
    }
    bool operator<(const EncryptionEngine& other) const {
        return operationCount < other.operationCount;
    }
    friend ostream& operator<<(ostream& os, const EncryptionEngine& e) {
        os << "Engine[" << e.engineName << "] | "
           << e.activeKey << " | Operations: " << e.operationCount;
        return os;
    }
};

#endif // CRYPTOLIB_H
